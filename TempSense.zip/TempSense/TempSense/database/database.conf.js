module.exports = {
    
    cvgData: {
        user: 'apptest',
        password: 'apptest',
        connectString: '129.213.155.161:1530/anapdb',
        poolMin: 10,
        poolMax: 10,
        poolIncrement: 0
    }
}